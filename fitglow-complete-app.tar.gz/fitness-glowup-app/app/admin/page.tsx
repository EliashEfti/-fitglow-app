"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  DollarSign, 
  TrendingUp, 
  Activity,
  Settings,
  Shield,
  BarChart3,
  UserCheck,
  CreditCard,
  MessageSquare,
  Star,
  Globe,
  Smartphone
} from "lucide-react";

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });

  // Mock admin credentials (replace with real authentication)
  const adminCredentials = {
    username: "admin",
    password: "fitglow2024"
  };

  const handleLogin = () => {
    if (loginForm.username === adminCredentials.username && 
        loginForm.password === adminCredentials.password) {
      setIsAuthenticated(true);
    } else {
      alert("Invalid credentials! Use: admin / fitglow2024");
    }
  };

  const stats = {
    totalUsers: 12547,
    premiumUsers: 3421,
    totalRevenue: 89650,
    monthlyRevenue: 15420,
    activeCoaches: 47,
    totalSessions: 8934,
    avgRating: 4.8,
    supportTickets: 23
  };

  const recentUsers = [
    { id: 1, name: "Sarah Ahmed", email: "sarah@example.com", plan: "Premium", joined: "2024-01-15", country: "🇧🇩 Bangladesh" },
    { id: 2, name: "John Smith", email: "john@example.com", plan: "Free", joined: "2024-01-14", country: "🇺🇸 USA" },
    { id: 3, name: "Priya Sharma", email: "priya@example.com", plan: "Premium", joined: "2024-01-13", country: "🇮🇳 India" },
    { id: 4, name: "Emma Wilson", email: "emma@example.com", plan: "Premium", joined: "2024-01-12", country: "🇬🇧 UK" },
    { id: 5, name: "Ahmed Hassan", email: "ahmed@example.com", plan: "Free", joined: "2024-01-11", country: "🇪🇬 Egypt" }
  ];

  const recentPayments = [
    { id: 1, user: "Sarah Ahmed", amount: "$29.99", method: "bKash", status: "Success", date: "2024-01-15" },
    { id: 2, user: "Emma Wilson", amount: "$299.99", method: "Credit Card", status: "Success", date: "2024-01-14" },
    { id: 3, user: "Priya Sharma", amount: "$29.99", method: "Credit Card", status: "Success", date: "2024-01-13" },
    { id: 4, user: "Mike Chen", amount: "$299.99", method: "Credit Card", status: "Failed", date: "2024-01-12" },
    { id: 5, user: "Lisa Martinez", amount: "$29.99", method: "bKash", status: "Success", date: "2024-01-11" }
  ];

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Shield className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold">FitGlow Admin</span>
            </div>
            <CardTitle>Admin Login</CardTitle>
            <CardDescription>Enter your credentials to access the dashboard</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">Username</label>
              <Input
                type="text"
                placeholder="Enter username"
                value={loginForm.username}
                onChange={(e) => setLoginForm({...loginForm, username: e.target.value})}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Password</label>
              <Input
                type="password"
                placeholder="Enter password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
            </div>
            <Button onClick={handleLogin} className="w-full">
              <Shield className="h-4 w-4 mr-2" />
              Login to Dashboard
            </Button>
            <div className="text-xs text-gray-500 text-center">
              Demo credentials: admin / fitglow2024
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold">FitGlow Admin</span>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="secondary">Admin Panel</Badge>
              <Button variant="outline" onClick={() => setIsAuthenticated(false)}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">+12% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Premium Users</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.premiumUsers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">+8% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${stats.monthlyRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">+15% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Coaches</CardTitle>
              <UserCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeCoaches}</div>
              <p className="text-xs text-muted-foreground">+3 new this month</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="coaches">Coaches</TabsTrigger>
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">New premium subscription from Sarah Ahmed</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Coach Mike Chen completed 5 sessions</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <span className="text-sm">New workout plan published</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      <span className="text-sm">Payment processed via bKash</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Platform Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm">Total Sessions</span>
                      <span className="font-semibold">{stats.totalSessions.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Average Rating</span>
                      <span className="font-semibold">{stats.avgRating}/5.0</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Support Tickets</span>
                      <span className="font-semibold">{stats.supportTickets}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Total Revenue</span>
                      <span className="font-semibold">${stats.totalRevenue.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Users</CardTitle>
                <CardDescription>Latest user registrations and activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-semibold">{user.name}</div>
                          <div className="text-sm text-gray-600">{user.email}</div>
                          <div className="text-xs text-gray-500">{user.country}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={user.plan === 'Premium' ? 'default' : 'secondary'}>
                          {user.plan}
                        </Badge>
                        <div className="text-xs text-gray-500 mt-1">Joined {user.joined}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Payments</CardTitle>
                <CardDescription>Payment transactions and revenue tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentPayments.map((payment) => (
                    <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <CreditCard className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <div className="font-semibold">{payment.user}</div>
                          <div className="text-sm text-gray-600">{payment.method}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{payment.amount}</div>
                        <Badge variant={payment.status === 'Success' ? 'default' : 'destructive'}>
                          {payment.status}
                        </Badge>
                        <div className="text-xs text-gray-500 mt-1">{payment.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="coaches" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Coach Management</CardTitle>
                <CardDescription>Manage coaches and their performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <UserCheck className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Coach Management</h3>
                  <p className="text-gray-600 mb-4">View and manage all coaches on the platform</p>
                  <Button>View All Coaches</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="content" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Content Management</CardTitle>
                <CardDescription>Manage workout plans, articles, and media</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-6 border rounded-lg">
                    <Activity className="h-12 w-12 text-blue-600 mx-auto mb-2" />
                    <h3 className="font-semibold">Workout Plans</h3>
                    <p className="text-sm text-gray-600">200+ plans</p>
                  </div>
                  <div className="text-center p-6 border rounded-lg">
                    <MessageSquare className="h-12 w-12 text-green-600 mx-auto mb-2" />
                    <h3 className="font-semibold">Articles</h3>
                    <p className="text-sm text-gray-600">150+ articles</p>
                  </div>
                  <div className="text-center p-6 border rounded-lg">
                    <Smartphone className="h-12 w-12 text-purple-600 mx-auto mb-2" />
                    <h3 className="font-semibold">Videos</h3>
                    <p className="text-sm text-gray-600">300+ videos</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Platform Settings</CardTitle>
                <CardDescription>Configure platform settings and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Payment Settings</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span>bKash Integration</span>
                        <Badge variant="default">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Stripe Integration</span>
                        <Badge variant="default">Active</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Language Settings</h3>
                    <div className="flex items-center space-x-2">
                      <Globe className="h-5 w-5 text-blue-600" />
                      <span>10 languages supported</span>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Mobile App</h3>
                    <div className="flex items-center space-x-2">
                      <Smartphone className="h-5 w-5 text-green-600" />
                      <span>Android app ready for deployment</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
