import type { Config } from 'drizzle-kit';

export default {
  schema: './lib/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    host: 'localhost',
    port: 5432,
    user: process.env.PGUSER!,
    password: process.env.PGPASSWORD!,
    database: 'fitness_glowup_app',
  },
} satisfies Config;
