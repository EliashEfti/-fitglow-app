"use client";

import { useState } from "react";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Users, 
  Star, 
  MapPin, 
  Clock, 
  Award,
  Heart,
  MessageCircle,
  Search,
  Filter,
  Dumbbell,
  Sparkles,
  Target,
  TrendingUp
} from "lucide-react";

export default function CoachesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSpecialty, setSelectedSpecialty] = useState("All");

  const specialties = ["All", "Fitness", "Nutrition", "Beauty", "Wellness", "Weight Loss", "Strength Training"];

  const coaches = [
    {
      id: 1,
      name: "Sarah Johnson",
      specialty: "Fitness & Nutrition",
      location: "New York, USA",
      rating: 4.9,
      reviews: 127,
      experience: "8 years",
      price: "$75/session",
      image: "👩‍💼",
      bio: "Certified personal trainer and nutritionist specializing in sustainable lifestyle changes.",
      achievements: ["NASM Certified", "Nutrition Specialist", "500+ Success Stories"],
      availability: "Available Today"
    },
    {
      id: 2,
      name: "Fatima Rahman",
      specialty: "Beauty & Wellness",
      location: "Dhaka, Bangladesh",
      rating: 4.8,
      reviews: 89,
      experience: "6 years",
      price: "৳3000/session",
      image: "👩‍⚕️",
      bio: "Licensed esthetician and wellness coach helping clients achieve their glow-up goals.",
      achievements: ["Licensed Esthetician", "Wellness Coach", "Beauty Expert"],
      availability: "Available Tomorrow"
    },
    {
      id: 3,
      name: "Mike Chen",
      specialty: "Strength Training",
      location: "Los Angeles, USA",
      rating: 4.9,
      reviews: 203,
      experience: "10 years",
      price: "$85/session",
      image: "👨‍💪",
      bio: "Former competitive bodybuilder now helping others build strength and confidence.",
      achievements: ["CSCS Certified", "Former Competitor", "Strength Specialist"],
      availability: "Available Today"
    },
    {
      id: 4,
      name: "Emma Thompson",
      specialty: "Weight Loss",
      location: "London, UK",
      rating: 4.7,
      reviews: 156,
      experience: "7 years",
      price: "£60/session",
      image: "👩‍🏫",
      bio: "Holistic approach to weight loss combining fitness, nutrition, and mindset coaching.",
      achievements: ["Holistic Health Coach", "Weight Loss Specialist", "Mindset Coach"],
      availability: "Available in 2 hours"
    },
    {
      id: 5,
      name: "Raj Patel",
      specialty: "Wellness",
      location: "Mumbai, India",
      rating: 4.8,
      reviews: 94,
      experience: "5 years",
      price: "₹2500/session",
      image: "👨‍⚕️",
      bio: "Yoga instructor and wellness coach focusing on mind-body connection.",
      achievements: ["Certified Yoga Instructor", "Wellness Expert", "Meditation Guide"],
      availability: "Available Today"
    },
    {
      id: 6,
      name: "Lisa Martinez",
      specialty: "Beauty",
      location: "Miami, USA",
      rating: 4.9,
      reviews: 178,
      experience: "9 years",
      price: "$70/session",
      image: "💄",
      bio: "Professional makeup artist and beauty consultant with celebrity clientele.",
      achievements: ["Celebrity Makeup Artist", "Beauty Consultant", "Style Expert"],
      availability: "Available Tomorrow"
    }
  ];

  const filteredCoaches = coaches.filter(coach => {
    const matchesSearch = coach.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         coach.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialty = selectedSpecialty === "All" || 
                            coach.specialty.toLowerCase().includes(selectedSpecialty.toLowerCase());
    return matchesSearch && matchesSpecialty;
  });

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-orange-50 to-red-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              <Users className="h-3 w-3 mr-1" />
              Expert Coaches
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Find Your Perfect
              <span className="bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                {" "}Fitness & Beauty{" "}
              </span>
              Coach
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Connect with certified trainers, nutritionists, beauty experts, and wellness coaches 
              who will guide you on your transformation journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-2xl mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search coaches by name or specialty..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button size="lg">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <Users className="h-8 w-8 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">50+</div>
              <div className="text-gray-600">Expert Coaches</div>
            </div>
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <Star className="h-8 w-8 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">4.8</div>
              <div className="text-gray-600">Average Rating</div>
            </div>
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <Award className="h-8 w-8 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">1000+</div>
              <div className="text-gray-600">Success Stories</div>
            </div>
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">95%</div>
              <div className="text-gray-600">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </section>

      {/* Specialty Filter */}
      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-2 justify-center">
            {specialties.map((specialty) => (
              <Button
                key={specialty}
                variant={selectedSpecialty === specialty ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedSpecialty(specialty)}
              >
                {specialty}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Coaches Grid */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Meet Our Expert Coaches
            </h2>
            <p className="text-xl text-gray-600">
              Certified professionals ready to help you achieve your goals
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCoaches.map((coach) => (
              <Card key={coach.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center pb-4">
                  <div className="text-6xl mb-4">{coach.image}</div>
                  <CardTitle className="text-xl">{coach.name}</CardTitle>
                  <Badge variant="secondary" className="mx-auto">
                    {coach.specialty}
                  </Badge>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{coach.rating}</span>
                    <span className="text-gray-500">({coach.reviews} reviews)</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4" />
                    {coach.location}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="h-4 w-4" />
                    {coach.experience} experience
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Target className="h-4 w-4" />
                    {coach.availability}
                  </div>
                  
                  <CardDescription className="text-sm">
                    {coach.bio}
                  </CardDescription>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-semibold">Achievements:</div>
                    <div className="flex flex-wrap gap-1">
                      {coach.achievements.map((achievement, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {achievement}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="text-lg font-bold text-orange-600">
                      {coach.price}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <MessageCircle className="h-4 w-4 mr-1" />
                        Chat
                      </Button>
                      <Button size="sm">
                        <Heart className="h-4 w-4 mr-1" />
                        Book
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {filteredCoaches.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Users className="h-16 w-16 mx-auto" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No coaches found</h3>
              <p className="text-gray-600">Try adjusting your search or filter criteria</p>
            </div>
          )}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600">
              Get started with your personal coach in 3 simple steps
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-orange-500 to-red-600 mx-auto mb-4">
                <Search className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Find Your Coach</h3>
              <p className="text-gray-600">
                Browse our certified coaches and find the perfect match for your goals and preferences.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-orange-500 to-red-600 mx-auto mb-4">
                <MessageCircle className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Book a Session</h3>
              <p className="text-gray-600">
                Schedule your first consultation to discuss your goals and create a personalized plan.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-orange-500 to-red-600 mx-auto mb-4">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Start Your Journey</h3>
              <p className="text-gray-600">
                Begin your transformation with expert guidance, support, and accountability.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Your Transformation?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of people who have achieved their goals with our expert coaches. 
            Your transformation journey starts with the right guidance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              <Heart className="h-4 w-4 mr-2" />
              Find Your Coach
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-white border-white hover:bg-white hover:text-orange-600"
            >
              <Dumbbell className="h-4 w-4 mr-2" />
              Become a Coach
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
