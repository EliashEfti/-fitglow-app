"use client";

import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Dumbbell, 
  Clock, 
  Target, 
  TrendingUp, 
  Heart, 
  Zap,
  Users,
  Play,
  BookOpen,
  Award
} from "lucide-react";

export default function FitnessPage() {
  const workoutPlans = [
    {
      title: "Beginner Full Body",
      duration: "30 min",
      difficulty: "Beginner",
      exercises: 8,
      description: "Perfect for those just starting their fitness journey",
      icon: Target
    },
    {
      title: "HIIT Cardio Blast",
      duration: "20 min",
      difficulty: "Intermediate",
      exercises: 6,
      description: "High-intensity interval training for maximum burn",
      icon: Zap
    },
    {
      title: "Strength Building",
      duration: "45 min",
      difficulty: "Advanced",
      exercises: 12,
      description: "Build muscle and increase overall strength",
      icon: Dumbbell
    },
    {
      title: "Core & Abs Focus",
      duration: "25 min",
      difficulty: "Intermediate",
      exercises: 10,
      description: "Strengthen your core with targeted exercises",
      icon: Target
    }
  ];

  const nutritionTips = [
    {
      title: "Meal Prep Basics",
      category: "Nutrition",
      readTime: "5 min read",
      description: "Learn how to prepare healthy meals for the entire week"
    },
    {
      title: "Pre-Workout Nutrition",
      category: "Performance",
      readTime: "3 min read",
      description: "What to eat before your workout for maximum energy"
    },
    {
      title: "Post-Workout Recovery",
      category: "Recovery",
      readTime: "4 min read",
      description: "Optimize your recovery with proper nutrition timing"
    },
    {
      title: "Hydration Guide",
      category: "Health",
      readTime: "2 min read",
      description: "How much water you really need for optimal performance"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              <Dumbbell className="h-3 w-3 mr-1" />
              Fitness & Workouts
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Expert
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {" "}Fitness Tips{" "}
              </span>
              & Workouts
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Transform your body with professional workout plans, nutrition guidance, 
              and expert fitness strategies for all levels.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg">
                <Play className="h-4 w-4 mr-2" />
                Start Workout
              </Button>
              <Button variant="outline" size="lg">
                <BookOpen className="h-4 w-4 mr-2" />
                Browse All Tips
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <Dumbbell className="h-8 w-8 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">200+</div>
              <div className="text-gray-600">Workout Plans</div>
            </div>
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">50K+</div>
              <div className="text-gray-600">Active Members</div>
            </div>
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <Award className="h-8 w-8 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">25+</div>
              <div className="text-gray-600">Expert Trainers</div>
            </div>
            <div className="p-6">
              <div className="flex justify-center mb-2">
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">95%</div>
              <div className="text-gray-600">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Workout Plans */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Popular Workout Plans
            </h2>
            <p className="text-xl text-gray-600">
              Choose from our expertly designed workout routines
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {workoutPlans.map((plan, index) => {
              const Icon = plan.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="text-center pb-4">
                    <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-4">
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-xl">{plan.title}</CardTitle>
                    <div className="flex justify-center gap-2 mt-2">
                      <Badge variant="secondary">
                        <Clock className="h-3 w-3 mr-1" />
                        {plan.duration}
                      </Badge>
                      <Badge variant="outline">{plan.difficulty}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardDescription className="mb-4">
                      {plan.description}
                    </CardDescription>
                    <div className="text-sm text-gray-500 mb-4">
                      {plan.exercises} exercises
                    </div>
                    <Button className="w-full">
                      <Play className="h-4 w-4 mr-2" />
                      Start Workout
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Nutrition Tips */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Nutrition & Wellness Tips
            </h2>
            <p className="text-xl text-gray-600">
              Fuel your body with expert nutrition advice
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {nutritionTips.map((tip, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary">{tip.category}</Badge>
                    <span className="text-sm text-gray-500">{tip.readTime}</span>
                  </div>
                  <CardTitle className="text-lg">{tip.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    {tip.description}
                  </CardDescription>
                  <Button variant="ghost" size="sm" className="w-full">
                    Read More →
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Transform Your Body?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of people who have achieved their fitness goals with our expert guidance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              <Heart className="h-4 w-4 mr-2" />
              Start Free Trial
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-white border-white hover:bg-white hover:text-blue-600"
            >
              <Users className="h-4 w-4 mr-2" />
              Find a Trainer
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
