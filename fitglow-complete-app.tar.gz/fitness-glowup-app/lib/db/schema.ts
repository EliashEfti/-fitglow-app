import { pgTable, serial, text, timestamp, integer, boolean, decimal, jsonb } from 'drizzle-orm/pg-core';

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: text('email').unique().notNull(),
  name: text('name').notNull(),
  avatar: text('avatar'),
  gender: text('gender'), // 'male', 'female', 'other'
  age: integer('age'),
  fitnessLevel: text('fitness_level'), // 'beginner', 'intermediate', 'advanced'
  goals: jsonb('goals'), // Array of fitness/beauty goals
  isCoach: boolean('is_coach').default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Coaches table (extended profile for coaches)
export const coaches = pgTable('coaches', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  bio: text('bio'),
  specialties: jsonb('specialties'), // Array of specialties
  experience: integer('experience'), // Years of experience
  certifications: jsonb('certifications'), // Array of certifications
  hourlyRate: decimal('hourly_rate', { precision: 10, scale: 2 }),
  rating: decimal('rating', { precision: 3, scale: 2 }).default('0'),
  totalSessions: integer('total_sessions').default(0),
  isVerified: boolean('is_verified').default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Tips/Articles table
export const tips = pgTable('tips', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  category: text('category').notNull(), // 'fitness', 'nutrition', 'skincare', 'hair', 'style'
  targetGender: text('target_gender'), // 'male', 'female', 'all'
  difficulty: text('difficulty'), // 'beginner', 'intermediate', 'advanced'
  tags: jsonb('tags'), // Array of tags
  authorId: integer('author_id').references(() => users.id),
  isPremium: boolean('is_premium').default(false),
  likes: integer('likes').default(0),
  views: integer('views').default(0),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Coaching sessions table
export const sessions = pgTable('sessions', {
  id: serial('id').primaryKey(),
  coachId: integer('coach_id').references(() => coaches.id),
  clientId: integer('client_id').references(() => users.id),
  title: text('title').notNull(),
  description: text('description'),
  scheduledAt: timestamp('scheduled_at').notNull(),
  duration: integer('duration').notNull(), // in minutes
  price: decimal('price', { precision: 10, scale: 2 }),
  status: text('status').default('scheduled'), // 'scheduled', 'completed', 'cancelled'
  meetingLink: text('meeting_link'),
  notes: text('notes'),
  rating: integer('rating'), // 1-5 stars
  feedback: text('feedback'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// AI Chat conversations
export const conversations = pgTable('conversations', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title'),
  messages: jsonb('messages'), // Array of messages
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// User progress tracking
export const userProgress = pgTable('user_progress', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  metric: text('metric').notNull(), // 'weight', 'body_fat', 'muscle_mass', etc.
  value: decimal('value', { precision: 10, scale: 2 }),
  unit: text('unit'), // 'kg', 'lbs', '%', etc.
  notes: text('notes'),
  recordedAt: timestamp('recorded_at').defaultNow(),
});
