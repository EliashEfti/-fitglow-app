"use client";

import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  Clock, 
  Star, 
  Heart, 
  Palette,
  Sun,
  Moon,
  Droplets,
  Shirt,
  Scissors,
  Camera,
  BookOpen
} from "lucide-react";

export default function GlowupPage() {
  const glowupCategories = [
    {
      title: "Skincare Routine",
      icon: Droplets,
      color: "from-blue-500 to-cyan-500",
      description: "Build the perfect skincare routine for your skin type",
      tips: 45
    },
    {
      title: "Makeup & Beauty",
      icon: Palette,
      color: "from-pink-500 to-rose-500",
      description: "Master makeup techniques and beauty trends",
      tips: 38
    },
    {
      title: "Fashion & Style",
      icon: Shirt,
      color: "from-purple-500 to-indigo-500",
      description: "Discover your personal style and fashion sense",
      tips: 52
    },
    {
      title: "Hair Care & Styling",
      icon: Scissors,
      color: "from-orange-500 to-red-500",
      description: "Transform your hair with expert care and styling tips",
      tips: 29
    }
  ];

  const dailyRoutines = [
    {
      title: "Morning Glow Routine",
      time: "15 min",
      steps: 6,
      icon: Sun,
      description: "Start your day with a radiant complexion"
    },
    {
      title: "Evening Wind-Down",
      time: "20 min",
      steps: 8,
      icon: Moon,
      description: "Nighttime routine for skin repair and relaxation"
    },
    {
      title: "Quick Touch-Up",
      time: "5 min",
      steps: 4,
      icon: Sparkles,
      description: "Fast beauty fixes for busy days"
    },
    {
      title: "Weekend Pamper",
      time: "60 min",
      steps: 12,
      icon: Heart,
      description: "Luxurious self-care routine for weekends"
    }
  ];

  const trendingTips = [
    {
      title: "Glass Skin Secrets",
      category: "Skincare",
      difficulty: "Beginner",
      description: "Achieve that coveted glass skin look with Korean beauty techniques"
    },
    {
      title: "Natural Makeup Look",
      category: "Makeup",
      difficulty: "Beginner",
      description: "Create a fresh, natural makeup look for everyday wear"
    },
    {
      title: "Capsule Wardrobe",
      category: "Fashion",
      difficulty: "Intermediate",
      description: "Build a versatile wardrobe with essential pieces"
    },
    {
      title: "Hair Mask DIY",
      category: "Hair Care",
      difficulty: "Beginner",
      description: "Nourish your hair with homemade natural treatments"
    },
    {
      title: "Confidence Building",
      category: "Mindset",
      difficulty: "All Levels",
      description: "Develop inner confidence that radiates outward"
    },
    {
      title: "Color Analysis",
      category: "Style",
      difficulty: "Intermediate",
      description: "Find your perfect color palette for makeup and clothing"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-pink-50 to-purple-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              <Sparkles className="h-3 w-3 mr-1" />
              Beauty & Style
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Your Ultimate
              <span className="bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                {" "}Glow-up{" "}
              </span>
              Guide
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Discover beauty secrets, skincare routines, style tips, and confidence-building 
              advice to help you look and feel your absolute best.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg">
                <Sparkles className="h-4 w-4 mr-2" />
                Start Your Glow-up
              </Button>
              <Button variant="outline" size="lg">
                <BookOpen className="h-4 w-4 mr-2" />
                Browse Beauty Tips
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Glow-up Categories
            </h2>
            <p className="text-xl text-gray-600">
              Explore different aspects of your transformation journey
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {glowupCategories.map((category, index) => {
              const Icon = category.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="text-center pb-4">
                    <div className={`inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r ${category.color} mx-auto mb-4`}>
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-xl">{category.title}</CardTitle>
                    <Badge variant="secondary" className="mx-auto">
                      {category.tips} tips
                    </Badge>
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardDescription className="mb-4">
                      {category.description}
                    </CardDescription>
                    <Button variant="ghost" size="sm" className="w-full">
                      Explore →
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Daily Routines */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Daily Beauty Routines
            </h2>
            <p className="text-xl text-gray-600">
              Structured routines for consistent glow-up results
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {dailyRoutines.map((routine, index) => {
              const Icon = routine.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="text-center pb-4">
                    <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-pink-500 to-purple-600 mx-auto mb-4">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-lg">{routine.title}</CardTitle>
                    <div className="flex justify-center gap-2 mt-2">
                      <Badge variant="secondary">
                        <Clock className="h-3 w-3 mr-1" />
                        {routine.time}
                      </Badge>
                      <Badge variant="outline">{routine.steps} steps</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardDescription className="mb-4">
                      {routine.description}
                    </CardDescription>
                    <Button size="sm" className="w-full">
                      <Camera className="h-4 w-4 mr-2" />
                      View Routine
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Trending Tips */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Trending Beauty Tips
            </h2>
            <p className="text-xl text-gray-600">
              Popular tips and techniques from beauty experts
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {trendingTips.map((tip, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary">{tip.category}</Badge>
                    <Badge variant="outline">{tip.difficulty}</Badge>
                  </div>
                  <CardTitle className="text-lg">{tip.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    {tip.description}
                  </CardDescription>
                  <Button variant="ghost" size="sm" className="w-full">
                    <Star className="h-4 w-4 mr-2" />
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-pink-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready for Your Glow-up Journey?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of people who have transformed their confidence and style with our expert beauty guidance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              <Heart className="h-4 w-4 mr-2" />
              Start Free Trial
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-white border-white hover:bg-white hover:text-pink-600"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Get Personal Style Guide
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
