"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  CreditCard, 
  Smartphone, 
  Shield, 
  CheckCircle, 
  AlertCircle,
  Loader2
} from "lucide-react";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  currency: string;
  description: string;
}

export function PaymentModal({ isOpen, onClose, amount, currency, description }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'bkash' | 'card' | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'success' | 'failed'>('idle');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: ''
  });
  const [bkashNumber, setBkashNumber] = useState('');

  const handleBkashPayment = async () => {
    setIsProcessing(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      const success = Math.random() > 0.1;
      
      if (success) {
        setPaymentStatus('success');
      } else {
        setPaymentStatus('failed');
      }
    } catch {
      setPaymentStatus('failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCardPayment = async () => {
    setIsProcessing(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2500));
      const success = Math.random() > 0.05;
      
      if (success) {
        setPaymentStatus('success');
      } else {
        setPaymentStatus('failed');
      }
    } catch {
      setPaymentStatus('failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const resetModal = () => {
    setPaymentMethod(null);
    setPaymentStatus('idle');
    setIsProcessing(false);
    setCardDetails({ number: '', expiry: '', cvv: '', name: '' });
    setBkashNumber('');
    onClose();
  };

  if (paymentStatus === 'success') {
    return (
      <Dialog open={isOpen} onOpenChange={resetModal}>
        <DialogContent className="sm:max-w-md">
          <div className="text-center py-8">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-2">Payment Successful!</h3>
            <p className="text-gray-600 mb-6">
              Your payment of {currency} {amount} has been processed successfully.
            </p>
            <Button onClick={resetModal}>
              Continue
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (paymentStatus === 'failed') {
    return (
      <Dialog open={isOpen} onOpenChange={resetModal}>
        <DialogContent className="sm:max-w-md">
          <div className="text-center py-8">
            <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-2">Payment Failed</h3>
            <p className="text-gray-600 mb-6">
              There was an issue processing your payment. Please try again.
            </p>
            <div className="flex gap-3 justify-center">
              <Button onClick={() => setPaymentStatus('idle')} variant="outline">
                Try Again
              </Button>
              <Button onClick={resetModal} variant="ghost">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">
            Choose Payment Method
          </DialogTitle>
          <p className="text-gray-600">
            {description} - {currency} {amount}
          </p>
        </DialogHeader>

        {!paymentMethod && (
          <div className="grid gap-4 py-6">
            {/* bKash Payment Option */}
            <Card 
              className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-pink-300"
              onClick={() => setPaymentMethod('bkash')}
            >
              <CardContent className="flex items-center gap-4 p-6">
                <div className="p-3 bg-pink-500 rounded-lg">
                  <Smartphone className="h-8 w-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold">bKash</h3>
                  <p className="text-gray-600">Pay with your bKash mobile wallet</p>
                  <Badge className="mt-2 bg-pink-100 text-pink-700">
                    Popular in Bangladesh
                  </Badge>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-500">Instant</div>
                  <div className="text-sm text-gray-500">No fees</div>
                </div>
              </CardContent>
            </Card>

            {/* Credit Card Payment Option */}
            <Card 
              className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-blue-300"
              onClick={() => setPaymentMethod('card')}
            >
              <CardContent className="flex items-center gap-4 p-6">
                <div className="p-3 bg-blue-500 rounded-lg">
                  <CreditCard className="h-8 w-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold">Credit/Debit Card</h3>
                  <p className="text-gray-600">Visa, Mastercard, American Express</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Shield className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-600">Secure & Encrypted</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-500">Worldwide</div>
                  <div className="text-sm text-gray-500">2.9% fee</div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* bKash Payment Form */}
        {paymentMethod === 'bkash' && (
          <div className="space-y-6 py-6">
            <div className="text-center">
              <div className="p-4 bg-pink-100 rounded-lg inline-block mb-4">
                <Smartphone className="h-12 w-12 text-pink-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Pay with bKash</h3>
              <p className="text-gray-600">Enter your bKash mobile number</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="bkash-number">
                  bKash Mobile Number
                </Label>
                <Input
                  id="bkash-number"
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={bkashNumber}
                  onChange={(e) => setBkashNumber(e.target.value)}
                />
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Payment Summary</h4>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Amount:</span>
                  <span>{currency} {amount}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">bKash Fee:</span>
                  <span className="text-green-600">Free</span>
                </div>
                <hr className="my-2" />
                <div className="flex justify-between font-semibold">
                  <span>Total:</span>
                  <span>{currency} {amount}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={() => setPaymentMethod(null)} 
                  variant="outline" 
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  onClick={handleBkashPayment}
                  disabled={!bkashNumber || isProcessing}
                  className="flex-1"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    `Pay ${currency} ${amount}`
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Credit Card Payment Form */}
        {paymentMethod === 'card' && (
          <div className="space-y-6 py-6">
            <div className="text-center">
              <div className="p-4 bg-blue-100 rounded-lg inline-block mb-4">
                <CreditCard className="h-12 w-12 text-blue-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Card Payment</h3>
              <p className="text-gray-600">Enter your card details securely</p>
            </div>

            <div className="grid gap-4">
              <div>
                <Label htmlFor="card-name">Cardholder Name</Label>
                <Input
                  id="card-name"
                  placeholder="John Doe"
                  value={cardDetails.name}
                  onChange={(e) => setCardDetails({...cardDetails, name: e.target.value})}
                />
              </div>

              <div>
                <Label htmlFor="card-number">Card Number</Label>
                <Input
                  id="card-number"
                  placeholder="1234 5678 9012 3456"
                  value={cardDetails.number}
                  onChange={(e) => setCardDetails({...cardDetails, number: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="card-expiry">Expiry Date</Label>
                  <Input
                    id="card-expiry"
                    placeholder="MM/YY"
                    value={cardDetails.expiry}
                    onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="card-cvv">CVV</Label>
                  <Input
                    id="card-cvv"
                    placeholder="123"
                    value={cardDetails.cvv}
                    onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})}
                  />
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Payment Summary</h4>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Amount:</span>
                  <span>{currency} {amount}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Processing Fee (2.9%):</span>
                  <span>{currency} {(amount * 0.029).toFixed(2)}</span>
                </div>
                <hr className="my-2" />
                <div className="flex justify-between font-semibold">
                  <span>Total:</span>
                  <span>{currency} {(amount * 1.029).toFixed(2)}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={() => setPaymentMethod(null)} 
                  variant="outline" 
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  onClick={handleCardPayment}
                  disabled={!cardDetails.name || !cardDetails.number || !cardDetails.expiry || !cardDetails.cvv || isProcessing}
                  className="flex-1"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    `Pay ${currency} ${(amount * 1.029).toFixed(2)}`
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
