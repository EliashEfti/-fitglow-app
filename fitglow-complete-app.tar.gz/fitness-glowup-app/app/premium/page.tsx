"use client";

import { useState } from "react";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PaymentModal } from "@/components/payment/payment-modal";
import { 
  Star, 
  Check, 
  Crown, 
  Zap,
  Heart,
  Target,
  Play,
  BookOpen,
  MessageCircle,
  Users,
  Award,
  Sparkles,
  TrendingUp,
  Shield,
  Clock
} from "lucide-react";

export default function PremiumPage() {
  const [showPayment, setShowPayment] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');

  const premiumFeatures = [
    {
      title: "1-on-1 AI Coaching",
      description: "Unlimited personalized conversations with our advanced AI coach",
      icon: MessageCircle,
      included: true
    },
    {
      title: "Premium Workout Plans",
      description: "Access to 500+ exclusive workout routines and training programs",
      icon: Target,
      included: true
    },
    {
      title: "HD Video Workouts",
      description: "Professional 4K workout videos with celebrity trainers",
      icon: Play,
      included: true
    },
    {
      title: "Advanced Progress Tracking",
      description: "Detailed analytics and insights on your fitness journey",
      icon: TrendingUp,
      included: true
    },
    {
      title: "Custom Meal Plans",
      description: "Personalized nutrition plans based on your goals and preferences",
      icon: BookOpen,
      included: true
    },
    {
      title: "Ad-Free Experience",
      description: "Enjoy FitGlow without any advertisements or interruptions",
      icon: Shield,
      included: true
    },
    {
      title: "Priority Coach Access",
      description: "Skip the queue and get instant access to premium coaches",
      icon: Users,
      included: true
    },
    {
      title: "Global Community Access",
      description: "Join exclusive premium groups and challenges worldwide",
      icon: Heart,
      included: true
    },
    {
      title: "Certification Programs",
      description: "Earn certificates for completing fitness and wellness programs",
      icon: Award,
      included: true
    },
    {
      title: "Beauty & Style Consultations",
      description: "Monthly 1-on-1 sessions with beauty and style experts",
      icon: Sparkles,
      included: true
    },
    {
      title: "Goal Tracking & Rewards",
      description: "Set goals, track progress, and earn rewards for achievements",
      icon: Crown,
      included: true
    },
    {
      title: "24/7 Premium Support",
      description: "Round-the-clock priority customer support and assistance",
      icon: Clock,
      included: true
    }
  ];

  const testimonials = [
    {
      name: "Rashida Ahmed",
      location: "Dhaka, Bangladesh",
      image: "👩‍💼",
      rating: 5,
      text: "FitGlow Premium transformed my life! The AI coaching and meal plans helped me lose 15kg in 6 months. The bKash payment made it so easy to subscribe!"
    },
    {
      name: "Jennifer Smith",
      location: "New York, USA",
      image: "👩‍🦰",
      rating: 5,
      text: "The HD workout videos and personal coaching are incredible. I've never been more motivated and the results speak for themselves!"
    },
    {
      name: "Priya Sharma",
      location: "Mumbai, India",
      image: "👩‍🎓",
      rating: 5,
      text: "The beauty consultations and style advice completely changed my confidence. The premium community is so supportive and inspiring!"
    }
  ];

  const plans = {
    monthly: {
      price: 29.99,
      period: "month",
      savings: null,
      popular: false
    },
    yearly: {
      price: 299.99,
      period: "year",
      savings: "Save $59.89",
      popular: true
    }
  };

  const handleSubscribe = (planType: 'monthly' | 'yearly') => {
    setSelectedPlan(planType);
    setShowPayment(true);
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-yellow-50 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              <Crown className="h-3 w-3 mr-1" />
              Premium Membership
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Unlock Your
              <span className="bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
                {" "}Full Potential{" "}
              </span>
              with Premium
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Get unlimited access to premium features, expert coaching, exclusive content, 
              and advanced tools to accelerate your fitness and glow-up journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={() => handleSubscribe('monthly')}>
                <Star className="h-4 w-4 mr-2" />
                Start Premium Trial
              </Button>
              <Button variant="outline" size="lg">
                <Play className="h-4 w-4 mr-2" />
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Choose Your Premium Plan
            </h2>
            <p className="text-xl text-gray-600">
              Flexible pricing options to fit your budget and goals
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
            {/* Monthly Plan */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="text-center pb-4">
                <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-4">
                  <Star className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl">Monthly Plan</CardTitle>
                <div className="text-4xl font-bold mt-4">
                  ${plans.monthly.price}
                  <span className="text-lg font-normal text-gray-600">/{plans.monthly.period}</span>
                </div>
                <CardDescription className="mt-2">
                  Perfect for getting started with premium features
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button 
                  className="w-full mb-6"
                  onClick={() => handleSubscribe('monthly')}
                >
                  Start Monthly Plan
                </Button>
                <div className="text-sm text-gray-600">
                  Cancel anytime • No commitment
                </div>
              </CardContent>
            </Card>

            {/* Yearly Plan */}
            <Card className="hover:shadow-lg transition-shadow border-2 border-yellow-400 relative">
              {plans.yearly.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-500 text-white">
                    <Crown className="h-3 w-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              <CardHeader className="text-center pb-4">
                <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-yellow-500 to-orange-600 mx-auto mb-4">
                  <Crown className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl">Yearly Plan</CardTitle>
                <div className="text-4xl font-bold mt-4">
                  ${plans.yearly.price}
                  <span className="text-lg font-normal text-gray-600">/{plans.yearly.period}</span>
                </div>
                {plans.yearly.savings && (
                  <Badge variant="secondary" className="mt-2">
                    {plans.yearly.savings}
                  </Badge>
                )}
                <CardDescription className="mt-2">
                  Best value for serious transformation goals
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button 
                  className="w-full mb-6 bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700"
                  onClick={() => handleSubscribe('yearly')}
                >
                  Start Yearly Plan
                </Button>
                <div className="text-sm text-gray-600">
                  Save 2 months • Best value
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Premium Features */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Get with Premium
            </h2>
            <p className="text-xl text-gray-600">
              Unlock all features and take your transformation to the next level
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {premiumFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-4">
                    <div className="flex items-start space-x-3">
                      <div className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-r from-green-500 to-blue-600 flex-shrink-0">
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{feature.title}</CardTitle>
                        <div className="flex items-center mt-1">
                          <Check className="h-4 w-4 text-green-500 mr-1" />
                          <span className="text-sm text-green-600 font-medium">Included</span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What Our Premium Members Say
            </h2>
            <p className="text-xl text-gray-600">
              Real stories from people who transformed their lives
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center pb-4">
                  <div className="text-4xl mb-2">{testimonial.image}</div>
                  <CardTitle className="text-lg">{testimonial.name}</CardTitle>
                  <CardDescription>{testimonial.location}</CardDescription>
                  <div className="flex justify-center gap-1 mt-2">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 italic">"{testimonial.text}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Frequently Asked Questions
            </h2>
          </div>
          
          <div className="max-w-3xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Can I cancel my subscription anytime?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Yes! You can cancel your premium subscription at any time. You'll continue to have access 
                  to premium features until the end of your current billing period.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">What payment methods do you accept?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We accept bKash (for Bangladesh users with no fees), credit/debit cards (Visa, Mastercard, 
                  American Express), and other local payment methods depending on your region.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Is there a free trial?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Yes! We offer a 7-day free trial for new premium subscribers. You can explore all premium 
                  features risk-free and cancel before the trial ends if you're not satisfied.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Can I switch between monthly and yearly plans?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Absolutely! You can upgrade or downgrade your plan at any time. Changes will take effect 
                  at your next billing cycle, and we'll prorate any differences.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-yellow-600 to-orange-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Transform Your Life?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of premium members who are achieving their fitness and beauty goals 
            faster with our expert guidance and advanced features.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              onClick={() => handleSubscribe('yearly')}
            >
              <Crown className="h-4 w-4 mr-2" />
              Start 7-Day Free Trial
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-white border-white hover:bg-white hover:text-yellow-600"
            >
              <Zap className="h-4 w-4 mr-2" />
              Compare Plans
            </Button>
          </div>
        </div>
      </section>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPayment}
        onClose={() => setShowPayment(false)}
        amount={plans[selectedPlan].price}
        currency="$"
        description={`FitGlow Premium - ${selectedPlan === 'monthly' ? 'Monthly' : 'Yearly'} Plan`}
      />
    </div>
  );
}
