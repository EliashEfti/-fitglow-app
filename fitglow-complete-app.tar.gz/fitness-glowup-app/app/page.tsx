"use client";

import { useState, useEffect } from "react";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PaymentModal } from "@/components/payment/payment-modal";
import { 
  Dumbbell, 
  Sparkles, 
  MessageCircle, 
  Users, 
  Crown,
  Star,
  TrendingUp,
  Heart,
  Target,
  Play,
  CheckCircle,
  ArrowRight,
  Mail,
  MapPin,
  Phone,
  Globe,
  Instagram,
  Twitter,
  Facebook,
  Youtube
} from "lucide-react";
import Link from "next/link";

export default function HomePage() {
  const [showPayment, setShowPayment] = useState(false);
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);

  // Register service worker
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then((registration) => {
          console.log('SW registered: ', registration);
        })
        .catch((registrationError) => {
          console.log('SW registration failed: ', registrationError);
        });
    }
  }, []);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setEmail("");
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  const stats = [
    { number: "10K+", label: "Active Users", icon: Users },
    { number: "500+", label: "Fitness Tips", icon: Target },
    { number: "200+", label: "Beauty Tips", icon: Sparkles },
    { number: "50+", label: "Expert Coaches", icon: Star },
  ];

  const features = [
    {
      title: "Fitness Tips",
      description: "Expert workout plans, nutrition guides, and fitness routines for all levels",
      icon: Dumbbell,
      href: "/fitness",
      gradient: "from-blue-500 to-cyan-500",
      badge: "200+ Plans"
    },
    {
      title: "Glow-up Guide",
      description: "Beauty tips, skincare routines, fashion advice, and confidence building",
      icon: Sparkles,
      href: "/glowup",
      gradient: "from-pink-500 to-rose-500",
      badge: "Daily Tips"
    },
    {
      title: "AI Assistant",
      description: "24/7 AI coach for personalized fitness and beauty advice",
      icon: MessageCircle,
      href: "/ai-chat",
      gradient: "from-purple-500 to-indigo-500",
      badge: "Smart AI"
    },
    {
      title: "Expert Coaches",
      description: "Connect with certified fitness and beauty professionals worldwide",
      icon: Users,
      href: "/coaches",
      gradient: "from-green-500 to-emerald-500",
      badge: "50+ Coaches"
    }
  ];

  const premiumFeatures = [
    "Unlimited AI coaching sessions",
    "Premium workout video library",
    "Custom meal and beauty plans",
    "Priority coach access",
    "Ad-free experience",
    "Advanced progress tracking"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4 md:mb-6">
              <Crown className="h-3 w-3 mr-1" />
              #1 Fitness & Beauty Platform
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 md:mb-6">
              Transform Your
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent animate-gradient">
                {" "}Body & Glow{" "}
              </span>
              with FitGlow
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-6 md:mb-8 max-w-2xl mx-auto">
              Get expert fitness tips, beauty advice, AI coaching, and connect with professional trainers. 
              Join thousands achieving their transformation goals.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8 md:mb-12">
              <Button size="lg" onClick={() => setShowPayment(true)} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <Crown className="h-4 w-4 mr-2" />
                Start Premium Trial
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/ai-chat">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Try AI Coach Free
                </Link>
              </Button>
            </div>
            
            {/* Quick Demo Video */}
            <div className="relative max-w-2xl mx-auto">
              <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 rounded-xl flex items-center justify-center border">
                <Button variant="ghost" size="lg" className="h-16 w-16 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur">
                  <Play className="h-8 w-8 ml-1" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-2">Watch 2-minute demo</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 md:py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mb-4">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="text-2xl md:text-3xl font-bold mb-1">{stat.number}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 md:py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Need to Transform
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive tools and expert guidance for your fitness and beauty journey
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer">
                  <Link href={feature.href}>
                    <CardHeader className="pb-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className={`inline-flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r ${feature.gradient}`}>
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <Badge variant="secondary">{feature.badge}</Badge>
                      </div>
                      <CardTitle className="text-xl group-hover:text-primary transition-colors">
                        {feature.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base mb-4">
                        {feature.description}
                      </CardDescription>
                      <div className="flex items-center text-primary font-medium">
                        <span>Explore now</span>
                        <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </CardContent>
                  </Link>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Premium Preview */}
      <section className="py-12 md:py-20 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4 md:mb-6">
              <Crown className="h-3 w-3 mr-1" />
              Premium Features
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4 md:mb-6">
              Unlock Your Full Potential
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 md:mb-12">
              Get unlimited access to premium features and accelerate your transformation
            </p>
            
            <div className="grid md:grid-cols-2 gap-6 md:gap-8 mb-8 md:mb-12">
              <div className="space-y-4">
                {premiumFeatures.slice(0, 3).map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3 text-left">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-4">
                {premiumFeatures.slice(3).map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3 text-left">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={() => setShowPayment(true)} className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700">
                <Crown className="h-4 w-4 mr-2" />
                Start 7-Day Free Trial
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/premium">
                  <Star className="h-4 w-4 mr-2" />
                  View All Features
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-12 md:py-16 bg-background">
        <div className="container mx-auto px-4">
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl md:text-3xl">Stay Updated</CardTitle>
              <CardDescription className="text-base">
                Get the latest fitness tips, beauty advice, and exclusive offers delivered to your inbox
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isSubscribed ? (
                <div className="text-center py-8">
                  <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Thank you for subscribing!</h3>
                  <p className="text-muted-foreground">You'll receive our latest updates and tips.</p>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4">
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="flex-1"
                  />
                  <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    <Mail className="h-4 w-4 mr-2" />
                    Subscribe
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 md:py-16 bg-muted/50 border-t">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            {/* Brand */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-blue-600 to-purple-600">
                  <Dumbbell className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-bold">FitGlow</span>
              </div>
              <p className="text-muted-foreground">
                Transform your body and glow up with expert guidance and AI-powered coaching.
              </p>
              <div className="flex space-x-4">
                <Button variant="ghost" size="icon">
                  <Instagram className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Youtube className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="font-semibold">Quick Links</h3>
              <div className="space-y-2">
                <Link href="/fitness" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Fitness Tips
                </Link>
                <Link href="/glowup" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Glow-up Guide
                </Link>
                <Link href="/ai-chat" className="block text-muted-foreground hover:text-foreground transition-colors">
                  AI Assistant
                </Link>
                <Link href="/coaches" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Expert Coaches
                </Link>
              </div>
            </div>

            {/* Premium */}
            <div className="space-y-4">
              <h3 className="font-semibold">Premium</h3>
              <div className="space-y-2">
                <Link href="/premium" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Premium Plans
                </Link>
                <Link href="/premium#features" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Features
                </Link>
                <Link href="/premium#pricing" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Pricing
                </Link>
                <Link href="/admin" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Admin Panel
                </Link>
              </div>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h3 className="font-semibold">Contact</h3>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span>support@fitglow.com</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>Global Platform</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Globe className="h-4 w-4" />
                  <span>10 Languages</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-muted-foreground text-sm">
              © 2024 FitGlow. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terms of Service
              </Link>
              <Link href="/support" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Support
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPayment}
        onClose={() => setShowPayment(false)}
        amount={29.99}
        currency="$"
        description="FitGlow Premium - Monthly Plan"
      />
    </div>
  );
}
