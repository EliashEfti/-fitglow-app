"use client";

import { useState } from "react";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Sparkles,
  Zap,
  Heart,
  Target,
  Clock,
  Star,
  Lightbulb,
  TrendingUp
} from "lucide-react";

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

export default function AIChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi! I'm your AI fitness and beauty assistant. I can help you with workout plans, nutrition advice, skincare routines, style tips, and more. What would you like to know?",
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const quickQuestions = [
    "Create a workout plan for beginners",
    "What's a good skincare routine?",
    "Healthy meal prep ideas",
    "How to build confidence?",
    "Best exercises for weight loss",
    "Natural makeup look tutorial"
  ];

  const aiFeatures = [
    {
      title: "Personalized Workouts",
      description: "Get custom workout plans based on your fitness level and goals",
      icon: Target,
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "Nutrition Guidance",
      description: "Receive meal plans and nutrition advice tailored to your needs",
      icon: Heart,
      color: "from-green-500 to-emerald-500"
    },
    {
      title: "Beauty & Style Tips",
      description: "Discover skincare routines and style advice for your unique features",
      icon: Sparkles,
      color: "from-pink-500 to-rose-500"
    },
    {
      title: "Progress Tracking",
      description: "Monitor your fitness and beauty journey with AI insights",
      icon: TrendingUp,
      color: "from-purple-500 to-indigo-500"
    }
  ];

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputMessage,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: messages.length + 2,
        text: getAIResponse(inputMessage),
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const getAIResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes("workout") || input.includes("exercise")) {
      return "Great! I'd love to help you with a workout plan. For beginners, I recommend starting with 3 days per week: Day 1 - Full body strength (squats, push-ups, planks), Day 2 - Cardio (20-30 min walking/jogging), Day 3 - Upper body focus. Would you like me to create a detailed plan based on your specific goals?";
    } else if (input.includes("skincare") || input.includes("skin")) {
      return "Skincare is so important! A basic routine should include: Morning - gentle cleanser, vitamin C serum, moisturizer, SPF 30+. Evening - cleanser, retinol (2-3x/week), moisturizer. Start simple and add products gradually. What's your skin type? I can give more specific recommendations!";
    } else if (input.includes("nutrition") || input.includes("meal") || input.includes("diet")) {
      return "Nutrition is key to your fitness journey! Focus on whole foods: lean proteins (chicken, fish, legumes), complex carbs (quinoa, sweet potatoes), healthy fats (avocado, nuts), and lots of vegetables. Meal prep tip: Cook proteins in bulk on Sunday! What are your specific nutrition goals?";
    } else if (input.includes("confidence") || input.includes("mindset")) {
      return "Building confidence is a beautiful journey! Start with small wins: set achievable daily goals, practice positive self-talk, celebrate your progress, and remember that confidence comes from self-acceptance and growth. Your glow-up is as much internal as external. What specific area would you like to work on?";
    } else {
      return "That's a great question! I'm here to help with all aspects of your fitness and beauty journey. Whether you need workout plans, nutrition advice, skincare routines, or confidence tips, I've got you covered. Could you tell me more about what you're looking to achieve?";
    }
  };

  const handleQuickQuestion = (question: string) => {
    setInputMessage(question);
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              <MessageCircle className="h-3 w-3 mr-1" />
              AI Assistant
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Your Personal
              <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                {" "}AI Coach{" "}
              </span>
              & Guide
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Get instant, personalized advice on fitness, nutrition, skincare, and style. 
              Your AI assistant is available 24/7 to help you achieve your goals.
            </p>
          </div>
        </div>
      </section>

      {/* AI Features */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold mb-4">What I Can Help You With</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {aiFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-4">
                    <div className={`inline-flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r ${feature.color} mx-auto mb-3`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Chat Interface */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Card className="h-[600px] flex flex-col">
              <CardHeader className="border-b">
                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-r from-green-500 to-blue-600">
                    <Bot className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">FitGlow AI Assistant</CardTitle>
                    <CardDescription>Online • Ready to help</CardDescription>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="flex-1 overflow-y-auto p-6">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex items-start space-x-2 max-w-[80%] ${message.isUser ? 'flex-row-reverse space-x-reverse' : ''}`}>
                        <div className={`flex h-8 w-8 items-center justify-center rounded-full ${message.isUser ? 'bg-blue-600' : 'bg-gradient-to-r from-green-500 to-blue-600'}`}>
                          {message.isUser ? (
                            <User className="h-4 w-4 text-white" />
                          ) : (
                            <Bot className="h-4 w-4 text-white" />
                          )}
                        </div>
                        <div className={`rounded-lg px-4 py-2 ${message.isUser ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-900'}`}>
                          <p className="text-sm">{message.text}</p>
                          <p className={`text-xs mt-1 ${message.isUser ? 'text-blue-100' : 'text-gray-500'}`}>
                            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="flex items-start space-x-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-green-500 to-blue-600">
                          <Bot className="h-4 w-4 text-white" />
                        </div>
                        <div className="bg-gray-100 rounded-lg px-4 py-2">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
              
              <div className="border-t p-4">
                <div className="flex space-x-2">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Ask me anything about fitness, beauty, or wellness..."
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1"
                  />
                  <Button onClick={handleSendMessage} disabled={!inputMessage.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Quick Questions */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h3 className="text-xl font-semibold mb-2">Quick Questions to Get Started</h3>
              <p className="text-gray-600">Click on any question to ask the AI assistant</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {quickQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-auto p-4 text-left justify-start"
                  onClick={() => handleQuickQuestion(question)}
                >
                  <Lightbulb className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">{question}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Get Unlimited AI Coaching
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Upgrade to premium for unlimited AI conversations, personalized plans, and advanced features.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              <Star className="h-4 w-4 mr-2" />
              Upgrade to Premium
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-white border-white hover:bg-white hover:text-green-600"
            >
              <Zap className="h-4 w-4 mr-2" />
              Try Free for 7 Days
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
